Developed a user-friendly Web application Fertimart for farmers to buy fertilizer online
Used ReactJS for frontend and sharing data between components
Added user authentication using a Google account with the help of Firebase authentication
Users can add products to their cart and proceed to the checkout page
